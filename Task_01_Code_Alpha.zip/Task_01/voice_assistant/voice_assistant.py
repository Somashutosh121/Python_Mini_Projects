import speech_recognition as sr
import pyttsx3
import datetime
import webbrowser
import wikipedia
import openai

# Set your OpenAI API key here

openai.api_key = "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"

# Initialize the speech engine

engine = pyttsx3.init()

#converts speech to text

def speak(text):
    print("Assistant:",text)
    engine.say(text)
    engine.runAndWait()

"""Greets user based on time of day"""

def greet_user():
    hour= datetime.datetime.now().hour
    if hour < 12 :
        speak("Good Morning!")
    elif hour < 18:
        speak("Good Afternoon!")
    else:
        speak("Good Evening")
        speak("I am your voice Assistant. How can i help you today!")  
        
"""Listens to the user's voice and returns text"""

def take_command():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening....")
        recognizer.adjust_for_ambient_noise(source)
        audio= recognizer.listen(source)
        
    
    try:
        print("Recognizing")
        command = recognizer.recognize_google(audio).lower()
        print("You Said:", command)
        return command
    except sr.UnknownValueError:
        speak("sorry i didn't understand that")
        return ""
    except sr.RequestError:
        speak("There is a connectivity issue :(")
        return ""
    
"""Sends a prompt to OpenAI ChatGPT and returns the response"""

def ask_chatgpt(question):
    try:
        response= openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful voice assistant."},
                {"role": "user", "content": question}
            ]
        )
        answer = response.choices[0].message.content.strip()
        return answer
    except Exception as e:
        print("ChatGPT error:", e) 
        return "Sorry, I couldn't connect to ChatGPT."
    
"""Processes user voice command"""

def process_command(command):
    if "time" in command:
        time = datetime.datetime.now().strftime("%I:%M %p")
        speak(f"The current time is {time}")

    elif "date" in command:
        date = datetime.datetime.now().strftime("%A, %B %d, %Y")
        speak(f"Today is {date}")

    elif "open youtube" in command:
        speak("Opening YouTube")
        webbrowser.open("https://www.youtube.com")

    elif "open google" in command:
        speak("Opening Google")
        webbrowser.open("https://www.google.com")

    elif "who is" in command or "what is" in command:
        try:
            topic = command.replace("who is", "").replace("what is", "").strip()
            summary = wikipedia.summary(topic, sentences=2)
            speak(summary)
        except:
            speak("Sorry, I couldn't find that on Wikipedia.")

    elif "stop" in command or "exit" in command:
        speak("Goodbye!")
        exit()

    else:
        # Fallback to ChatGPT for any other question
        speak("Let me think about that...")
        response = ask_chatgpt(command)
        speak(response)

# === MAIN PROGRAM ===

if __name__ == "__main__":
    greet_user()
    while True:
        cmd = take_command()
        if cmd:
            process_command(cmd)


     
    
    
 